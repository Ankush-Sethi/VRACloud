import pysnow

class Snow(object):
	def __init__(self, host, user, pwd, ssl_verify=True, table="incident"):
		self.client = pysnow.Client(
			host=host, user=user, password=pwd, use_ssl=ssl_verify
		)
		self.table = self.client.resource(api_path='/table/'+table)
		self.status_code = None
		self.reason = None

	def last_failure_reason(self):
		if self.status_code not in [200,201,202]:
			return self.reason

		return False

	def get_by_deployment_id(self, deployment_id):
		return self._prepare_resp(
			self.table.get(query={'x_vmw_cloudservice_deployment_id':deployment_id})._response
		)

	def update_by_sys_id(self, id, data):
		return self._prepare_resp(
			self.table.update(query={'sys_id': id}, payload=data)._response
		)

	def update_by_number(self, q_number, data):
		return self._prepare_resp(
			self.table.update(query={'number': q_number}, payload=data)._response
		)

	def _prepare_resp(self, resp):
		self.status_code = resp.status_code
		self.reason = resp.reason

		return resp.content if hasattr(resp, 'content') else ''
