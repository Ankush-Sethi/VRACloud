###
# #%L
# abx.post_provision
# %%
# Copyright (C) 2022 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###

class AbxService:
	ACTIONS_PATH = '/abx/api/resources/actions'
	ACTION_RUNS_PATH = '/abx/api/resources/action-runs'
	ACTION_SECRETS_PATH = '/abx/api/resources/action-secrets'

	def __init__(self, auth) -> None:
		self.vra_client = auth

	def is_failed_response(self):
		return self.vra_client.is_failed_response()
	
	def get_abx_constants(self):
		path = AbxService.ACTION_SECRETS_PATH

		return self.vra_client.get(path)

	def import_abx_constant(self, body):
		# body in format {"encrypted":bool, "name": "string", "value": "string"|{}}
		path = AbxService.ACTION_SECRETS_PATH
		
		return self.vra_client.post(path, body)

	def update_abx_constant(self, id, body):
		# body in format {"encrypted":bool, "name": "string", "value": "string"|{}}
		path = AbxService.ACTION_SECRETS_PATH + "/" + str(id)
		
		return self.vra_client.put(path, body)

	def get_abx_actions(self):
		path = AbxService.ACTIONS_PATH + "?size=1000000&%24filter=system%20eq%20%27false%27&projection=true"
		
		return self.vra_client.get(path)

	def get_abx_actions_by_name(self, name):
		path = AbxService.ACTION_SECRETS_PATH + "?page=0&size=1000000&$filter=name%20eq%20%27" + name + "%27"
		
		return self.vra_client.get(path)

	def get_abx_action(self, id, project_id):
		path = AbxService.ACTIONS_PATH + "/" + id + '?projectId=' + project_id
		
		return self.vra_client.get(path)

	def update_abx_action(self, id, body):
		path = AbxService.ACTIONS_PATH + "/" + id

		return self.vra_client.put(path, body)

	def run_abx_action(self, action_id, body):
		path = AbxService.ACTIONS_PATH + "/" + action_id + "/action-runs"

		return self.vra_client.post(path, body)

	def get_abx_action_run_by_id(self, action_run):
		path = AbxService.ACTION_RUNS_PATH + "/" + action_run

		return self.vra_client.get(path)

	def export_abx_action(self, body):
		path = AbxService.ACTIONS_PATH + "/export"
		body = {
			"actions": [body]
		}
		
		return self.vra_client.post(path, body)
