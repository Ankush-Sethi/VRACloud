###
# #%L
# abx.post_provision
# %%
# Copyright (C) 2022 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###
import json

class EventBrokerService:
	def __init__(self, auth) -> None:
		self.vra_client = auth

	def is_failed_response(self):
		return self.vra_client.is_failed_response()
	
	def get_subscriptions(self):
		path = "/event-broker/api/subscriptions?$filter=type ne 'SUBSCRIBABLE'"

		return self.vra_client.get(path)

	def get_subscriptions_by_name(self, subscription_name):
		resp = []

		subs = self.get_subscriptions()

		if self.is_failed_response():
			return resp

		return list(filter(lambda d: d['name'] == subscription_name, json.loads(subs.content.decode("utf-8"))['content']))

	def modify_subscription(self, body):
		path = "/event-broker/api/subscriptions";

		return self.vra_client.post(path, body)
