###
# #%L
# abx.post_provision
# %%
# Copyright (C) 2022 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###

class BlueprintService:
	def __init__(self, auth) -> None:
		self.vra_client = auth

	def is_failed_response(self):
		return self.vra_client.is_failed_response()
	
	def get_blueprint_request_by_id(self, request_id):
		path = '/blueprint/api/blueprint-requests/' + request_id

		return self.vra_client.get(path)
	