###
# #%L
# abx.post_provision
# %%
# Copyright (C) 2022 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###

class PlatformService:
	def __init__(self, auth) -> None:
		self.vra_client = auth

	def is_failed_response(self):
		return self.vra_client.is_failed_response()
	
	def get_secrets(self):
		path = '/platform/api/secrets?page=0&size=100000'

		return self.vra_client.get(path)

	def add_secret(self, body):
		path = '/platform/api/secrets'

		return self.vra_client.post(path, body)
