###
# #%L
# abx.post_provision
# %%
# Copyright (C) 2022 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###

class MachineService:
	def __init__(self, auth) -> None:
		self.vra_client = auth

	def is_failed_response(self):
		return self.vra_client.is_failed_response()
	
	def get_iaas_machines(self):
		path = '/iaas/api/machines?$top=100000'

		return self.vra_client.get(path)

	def get_iaas_machine_by_id(self, machine_id):
		path = '/iaas/api/machines/%s' % (machine_id)

		return self.vra_client.get(path)

	def get_iaas_machine_by_odata_filter(self, filter):
		path = '/iaas/api/machines?$filter=' + filter 

		return self.vra_client.get(path)

	def update_iaas_machine(self, machine_id, body):
		path = '/iaas/api/machines/%s' % machine_id

		return self.vra_client.patch(path, body)
	