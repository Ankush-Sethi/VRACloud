###
# #%L
# abx.post_provision
# %%
# Copyright (C) 2022 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###
import json
import requests

requests.packages.urllib3.disable_warnings(
	requests.packages.urllib3.exceptions.InsecureRequestWarning)

class AuthClientService:
	def __init__(self, host, port, username='', password='', domain='', refresh_token='', ssl_validate=True):
		self.vra_client_config={
			'host': host,
			'port': port,
			'username': username,
			'password': password,
			'domain': domain,
			'refresh_token': refresh_token,
			'connection_certificate_check': ssl_validate
		}

		self.base_url = "https://{}:{}".format(self.vra_client_config['host'], self.vra_client_config['port'])
		
		self.session = requests.session()
		self.session.verify = self.vra_client_config['connection_certificate_check']
		self.resp = None
		self.bearer = None
		self._login()

	def get(self, path):
		self.resp = self.session.get(url=self._get_url(path))
		return self.resp

	def delete(self, path):
		self.resp = self.session.delete(url=self._get_url(path))
		return self.resp

	def post(self, path, body):
		self.resp = self.session.post(url=self._get_url(path), json=body)
		return self.resp

	def put(self, path, body):
		self.resp = self.session.put(url=self._get_url(path), json=body)
		return self.resp

	def patch(self, path, body):
		self.resp = self.session.patch(url=self._get_url(path), json=body)
		return self.resp

	def is_failed_response(self):
		if self.resp.status_code in [200,201,202]:
			return False
		
		return self.resp.reason

	def get_bearer(self):
		return self.bearer

	def _get_url(self, path):
		return "{}{}".format(self.base_url, path)

	def _login(self):
		if not '' == self.vra_client_config['refresh_token']:
			self._rt_login()
		else:
			self._up_login()
		
		self.session.headers.update({
			'Authorization': 'Bearer {}'.format(self.bearer)
		})
		
	def _rt_login(self):
		LOGIN_API = "/iaas/api/login"
		login_details = {
			"refreshToken": self.vra_client_config['refresh_token']
		}

		self.resp = self.post(path=LOGIN_API, body=login_details)
		if self.is_failed_response():
			raise Exception('Cannot login to vRA. Reason: '+ self.is_failed_response())
		
		content = json.loads(self.resp.content)

		self.bearer = content.get("token")

	def _up_login(self):
		LOGIN_API = "/csp/gateway/am/api/login"
		login_details = {
			"username": self.vra_client_config['username'], 
			"password": self.vra_client_config['password'],
			"domain": self.vra_client_config['domain']
		}

		self.resp = self.post(path=LOGIN_API, body=login_details)
		if self.is_failed_response():
			raise Exception ('Cannot login to vRA. Reason: '+ self.is_failed_response())

		content = json.loads(self.resp.content)

		self.bearer = content.get("cspAuthToken")
