import logging, re, json, ast, time

class HostnameGenerator:
	def __init__(self, abx_service, template, existing_hostnames, configs, validate_hostame={'vra_machine_service': None}, locker=None):
		self.abx_service = abx_service
		self.template = template
		self.existing_hostnames = existing_hostnames
		self.validate_hostame = validate_hostame
		self.locker = locker

		self.auto_fill_indexes = bool('auto_fill_indexes' in configs and configs['auto_fill_indexes'] or False)
		self.start_index = int('start_index' in configs and configs['start_index'] or 0)
		self.increment_step = int('increment_step' in configs and configs['increment_step'] or 1)
		self.max_attempts = int('max_attempts' in configs and configs['max_attempts'] or 3)
		self.retry_period = int('retry_period' in configs and configs['retry_period'] or 15)
		self.index_constant_name = str('configuration_name' in configs and configs['configuration_name'] or '_customHostname')

		self.abx_constant_id = None
		self.abx_constant_value = None
		self.abx_constant_body = None

		self.logger = logging.getLogger()

		self._validate_template()

	def get_valid_hostname(self):
		hostname = None 
		test_hostname = None

		self.logger.debug('Resolved name: %s' % (self.template))

		template_match = re.search('^([^#]+)?(#+)?([^#]+)?$',self.template)

		if template_match is None:
			message = 'Template cannot be parsed. Template %s' % (self.template)
			self.logger.critical(message)
			raise Exception (message)
				
		machine_prefix = str(template_match[1] or '')
		digits_pattern = str(template_match[2] or '')
		machine_suffix = str(template_match[3] or '')

		if digits_pattern == '': 
			self.logger.warning('Empty digits pattern, the default (###) will be applied to the end.')

		self.logger.debug('digits pattern - %s \n machine prefix: %s \n machine suffix: %s' % (digits_pattern, machine_prefix, machine_suffix))

		i = 0
		while i < self.max_attempts:
			try:
				if self.locker is not None:
					self.locker.lock_and_wait()

				test_hostname = self._generate_hostname(machine_prefix, digits_pattern, machine_suffix)
			finally:
				if self.locker is not None:
					self.locker.unlock()
				i = i + 1
			
			# add test hostname in all cases regardless if it is valid or not; if it is valid, it will be given to VM has it has to be removed from valid list
			self.existing_hostnames.append(test_hostname)

			if self._validate_hostname(test_hostname):
				hostname = test_hostname
				break
			else: 
				self.logger.error('Cannot use hostname: %s' % (test_hostname))
				self.logger.debug('Have another %s retries.' % (self.max_attempts - (i + 1)))

		if hostname is None:
			error_message = 'No valid custom hostname was generated.';
			self.logger.error(error_message);
			raise Exception (error_message)
		
		return hostname

	def _generate_hostname(self, machine_prefix, digits_pattern, machine_suffix):
		digits = None

		if self.auto_fill_indexes:
			digits = self._get_next_machine_digits_using_autofil(machine_prefix, machine_suffix)
		else:
			digits = self._get_next_machine_digits_using_configurations(machine_prefix, machine_suffix)

		return self._format_digit_pattern(digits_pattern, digits)

	def _format_digit_pattern(self, pattern, number):
		if '' == pattern and not '#' == self.template:
			# if no digits pattern (###) - apply a valid one; second check is made because of pattern is taken 1 time, while template might be changed after first try
			pattern = '#' * len(str(number))
			self.template = self.template + pattern
		elif len(str(number)) > len(pattern):
			raise Exception ('Digits exceeds maximum length of %s' % (len(pattern)))

		digit_string = ('0' * len(pattern) + str(number))[-len(pattern):]

		return self.template.replace(pattern, digit_string)

	def _get_next_machine_digits_using_autofil(self, machine_prefix, machine_suffix):
		matching_numbers=[]

		for hostname in existing_hostnames:
			hostname_match = re.search('^%s([0-9]+)%s$' % (machine_prefix, machine_suffix), hostname)
  
			if hostname_match is not None:
				matching_numbers.append(int(hostname_match[1]))

		self.logger.info('Taken numbers: %s' % (matching_numbers));

		# get next free number
		next_free_number = self.start_index

		while True:
			if next_free_number not in matching_numbers:
				break
			next_free_number = next_free_number + self.increment_step

		return next_free_number

	def _get_next_machine_digits_using_configurations(self, machine_prefix, machine_suffix):
		next_index_name = '_%s%snextIndex' % (machine_prefix, machine_suffix) 
		next_free_number = self.start_index
		
		self._reload_config()

		# check if there is property for this machine index
		if next_index_name in self.abx_constant_value:
			next_free_number = self.abx_constant_value[next_index_name]

		next_index_value = next_free_number + self.increment_step

		# give some seconds in advance to wait_time to cover execution time
		self.abx_constant_value[next_index_name] = next_index_value

		body = self.abx_constant_body
		body['value'] = str(self.abx_constant_value)

		self.abx_service.update_abx_constant(self.abx_constant_id, body)

		if self.abx_service.is_failed_response():
			raise Exception (self.abx_service.is_failed_response())

		self.logger.debug('Next machine index `%s` for prefix `%s` saved.' % (next_index_value, next_index_name))

		return next_free_number

	def _update_config(self, body):
		self.abx_service.update_abx_constant(self.abx_constant_id, body)

		if self.abx_service.is_failed_response():
			raise Exception (self.abx_service.is_failed_response())

	def _reload_config(self):
		resp = self.abx_service.get_abx_actions_by_name(self.index_constant_name)

		if self.abx_service.is_failed_response():
			raise Exception (self.abx_service.is_failed_response())

		abx_constants = json.loads(resp.content.decode("utf-8"))

		if 0 == abx_constants['numberOfElements']:
			raise Exception ('Cannot find ABX constant with name `%s`' % (self.index_constant_name))
		elif 1 < abx_constants['numberOfElements']:
			raise Exception ('Multiple constants with name `%s` are found. Aborting' % (self.index_constant_name))

		if self.abx_constant_id is None:
			self.abx_constant_id = abx_constants['content'][0]['id']

		self.abx_constant_body = abx_constants['content'][0]

		# convert string to dictionary
		if isinstance(self.abx_constant_body['value'], dict): 
			self.abx_constant_value = self.abx_constant_body['value']
		else:	
			try:
				self.abx_constant_value = json.loads(self.abx_constant_body['value'])
			except Exception as e:
				self.abx_constant_value = ast.literal_eval(self.abx_constant_body['value']) 

		self.logger.debug('Action constant `%s` value: %s' % (self.index_constant_name, self.abx_constant_value))

	def _validate_template(self):
		if not re.search("^[a-zA-Z0-9-_.#]*$", self.template):
			raise Exception ('Template contains illegal characters. Allowed symbols: "a-z", "A-Z", "0-9", "#", ".", "-" and "_"');
		
	def _validate_hostname(self, hostname):
		# different validations implemented here - generated hostname has to be checked one more time in respective place

		# vRA
		if 'vra_machine_service' in self.validate_hostame \
			and self.validate_hostame['vra_machine_service'] is not None \
			and not self._validate_hostname_vra(hostname):
			
			return False

		return True

	def _validate_hostname_vra(self, hostname):
		machine_service = self.validate_hostame['vra_machine_service']
		filter_condition = "name eq '%s'" % (hostname)

		resp = machine_service.get_iaas_machine_by_odata_filter(filter_condition)

		if machine_service.is_failed_response():
			raise Exception (machine_service.is_failed_response())

		machines = json.loads(resp.content.decode("utf-8"))

		if machines['numberOfElements'] > 0 :
			self.logger.error('Machine with name `%s` already exists in vRA.' % (hostname))
			return False

		return True
