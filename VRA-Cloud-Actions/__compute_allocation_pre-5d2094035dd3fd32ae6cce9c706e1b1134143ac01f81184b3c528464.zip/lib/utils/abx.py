###
# #%L
# abx.post_provision
# %%
# Copyright (C) 2022 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###
import sys, ast, json

class ABX:
	def __init__(self, context):
		self.context = context

	def decrypt_string(self, string):
		# prepared for testing on local environment
		if 'getSecret' not in dir(self.context):
			return string

		return self.context.getSecret(string)

	def decrypt_dict(self, dict):
		decrypted_dict={}

		for key in dict.keys():
			decrypted_dict[key] = self.decrypt_string(dict[key])

		return decrypted_dict

	def normalize_inputs(self, inputs):
		for key in inputs:
			if isinstance(inputs[key], str) and len(inputs[key].strip()) and '{' == inputs[key].strip()[0]:
				try:
					inputs[key] = json.loads(inputs[key])
				except Exception:
					inputs[key] = ast.literal_eval(inputs[key]) 

	def validate_inputs(self, inputs, validations):
		for validation_element in validations:
			haystack_name = 'inputs'
			haystack_value = inputs
			error_string = 'as input parameter'

			for prop_name in validation_element[0]:
				haystack_name = "%s['%s']" % (haystack_name, prop_name)

				if prop_name not in haystack_value:
					return 'Mandatory parameter `%s` is missing %s' % (haystack_name, error_string)
					
				error_string = 'in `%s` input parameter' % (haystack_name)
				haystack_value = haystack_value[prop_name]

			for param in validation_element[1]:
				if param not in haystack_value:
					return 'Mandatory parameter `%s` is missing %s' % (param, error_string)
					 	
			if len(validation_element) > 2:
				for idx, subelement in enumerate(validation_element[1]):
					if haystack_value[subelement] not in validation_element[2][idx]:
						return 'The value `%s` of input parameter `%s[\'%s\']` is not among allowed values for parameter - `%s`' % (haystack_value[subelement], haystack_name, subelement, validation_element[2][idx])
			
		return False
