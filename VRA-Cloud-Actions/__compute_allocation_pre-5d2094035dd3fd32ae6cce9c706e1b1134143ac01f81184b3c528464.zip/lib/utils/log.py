###
# #%L
# abx.post_provision
# %%
# Copyright (C) 2022 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###
import logging, sys

class Logger:
	def __init__(self, lvl=logging.INFO):
		self.logger = logging.getLogger()
		
		self.logger.setLevel(lvl)
		console_handler = logging.StreamHandler()
		log_format = '%(asctime)s | %(levelname)s: %(message)s'
		console_handler.setFormatter(logging.Formatter(log_format))
		self.logger.addHandler(console_handler)
	
	def set_lvl(self, lvl):
		self.logger.setLevel(lvl*10)

	def debug(self, message):
		self.logger.debug(message)

	def info(self, message):
		self.logger.info(message)

	def warning(self, message):
		self.logger.warning(message)

	def error(self, message):
		self.logger.error(message)

	def critical(self, message, do_exit=True):
		if do_exit:
			raise Exception (message)
		else:
			self.logger.critical(message)			
