###
# #%L
# abx.post_provision
# %%
# Copyright (C) 2022 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###
import json, ast, re, xmltodict

class Misc:
	def __init__(self):
		pass # no pre-init required

	def x2bool(self, txt):
		if type(txt) == bool:
			return txt
		elif isinstance(txt, (int, float)):
			return bool(txt)
		return txt.lower() in ("yes", "true", "True", "t", "1")

	def validate_inputs(self, params, validations):
		for param in validations:
			if param not in params:
				return param
    
		return False

	def str2json(self, txt, is_bin=True):
		if is_bin:
			return json.loads(txt.decode("utf-8"))
		
		return json.loads(txt)

	def str2dict(self, txt, validate=True):
		if not validate or not isinstance(txt, (dict, list)):
			return ast.literal_eval(txt)

		return txt

	def xml2dict(self, txt, is_bin=True):
		if is_bin:
			return xmltodict.parse(txt.decode("utf-8"))
		
		return xmltodict.parse(txt)	

	def is_resp_html(self, txt, is_bin=True):
		if is_bin:
			txt = txt.decode("utf-8")
		
		return len(re.findall('^<html>.*</html>$', txt.strip(), re.MULTILINE|re.DOTALL)) > 0

	def compare_obj_props(self, o1, o2):
		return self._order_obj(o1, False) == self._order_obj(o2, False)

	def compare_obj(self, o1, o2):
		return self._order_obj(o1) == self._order_obj(o2)

	def _order_obj(self, obj, ord_value=True):
		if isinstance(obj, dict):
			return sorted((k, self._order_obj(v, ord_value)) for k, v in obj.items())
		if isinstance(obj, list):
			return sorted(self._order_obj(x, ord_value) for x in obj)
		else:
			if ord_value:
				return obj
			return '*****'
