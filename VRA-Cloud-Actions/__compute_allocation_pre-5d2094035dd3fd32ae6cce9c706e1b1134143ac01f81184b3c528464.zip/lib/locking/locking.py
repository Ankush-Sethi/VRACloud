# Check if ABX action is running (locked) in the 
# similar way LockingSystem in vRO is working 
# (it works using owner as well, but this might 
# bring issues in some cases). Keep in mind 
# there is no unlocking (unlikely to vRO)

import json, time, logging, ast

class Locking:
	LOCKING_TIME_PROP_NAME = '_locked_till'
	BUFFER_TIME_SECONDS = 1

	def __init__(self, abx_service, abx_constant_name):
		self.logger = logging.getLogger()
		self.abx_service = abx_service
		self.configuration_name = abx_constant_name
		self.abx_constant_id = None
		self.abx_constant_value = None
		self.abx_constant_body = None

	def lock(self, wait_time=15):
		lock_time = self._get_lock_time()
		if lock_time > self._curr_time_since_epoch():
			raise Exception ('Any operation locked till %s' % (self._epoch_to_datetime(lock_time)))

		self._do_lock_unlock(wait_time)

	def unlock(self):
		self._do_lock_unlock(-1)

	def lock_and_wait(self, wait_time=15):
		while True:
			try:
				self.lock(wait_time)
				break
			except Exception as e:
				# locked or other exception
				self.logger.info(str(e))
				time.sleep(wait_time)

	def _curr_time_since_epoch(self):
		return round(time.time()*1000)

	def _epoch_to_datetime(self, epoch):
		s, ms = divmod(epoch, 1000)

		return '%s.%03d' % (time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(s)), ms)


	def _get_lock_time(self):
		self._reload_config()

		if Locking.LOCKING_TIME_PROP_NAME in self.abx_constant_value:
			return self.abx_constant_value[Locking.LOCKING_TIME_PROP_NAME]

		return 0

	def _do_lock_unlock(self, wait_time):
		if wait_time > 0:
			wait_time = wait_time + Locking.BUFFER_TIME_SECONDS

		self._reload_config()

		# give some seconds in advance to wait_time to cover execution time
		self.abx_constant_value[Locking.LOCKING_TIME_PROP_NAME] = self._curr_time_since_epoch() + wait_time * 1000

		body = self.abx_constant_body
		body['value'] = str(self.abx_constant_value)

		self.abx_service.update_abx_constant(self.abx_constant_id, body)

		if self.abx_service.is_failed_response():
			raise Exception (self.abx_service.is_failed_response())

	def _reload_config(self):
		resp = self.abx_service.get_abx_actions_by_name(self.configuration_name)

		if self.abx_service.is_failed_response():
			raise Exception (self.abx_service.is_failed_response())

		abx_constants = json.loads(resp.content.decode("utf-8"))

		if 0 == abx_constants['numberOfElements']:
			raise Exception ('Cannot find ABX constant with name `%s`' % (self.configuration_name))
		elif 1 < abx_constants['numberOfElements']:
			raise Exception ('Multiple constants with name `%s` are found. Aborting' % (self.configuration_name))

		if self.abx_constant_id is None:
			self.abx_constant_id = abx_constants['content'][0]['id']

		self.abx_constant_body = abx_constants['content'][0]
		# convert string to dictionary
		try:
			self.abx_constant_value = json.loads(self.abx_constant_body['value'])
		except Exception as e:
			self.abx_constant_value = ast.literal_eval(self.abx_constant_body['value']) 

		self.logger.debug('Action constant `%s` value: %s' % (self.configuration_name, self.abx_constant_value))
		
