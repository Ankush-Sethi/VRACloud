###
# #%L
# abx.post_provision
# %%
# Copyright (C) 2022 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###
import requests, xmltodict

requests.packages.urllib3.disable_warnings(
	requests.packages.urllib3.exceptions.InsecureRequestWarning)

class QualysClient:
	def __init__(self, host, username, password, ssl_verify=True):
		self.base_url = 'https://%s/api/2.0/fo' % (host)

		self.client={
			'host': host,
			'username': username,
			'password': password,
			'ssl_verify': ssl_verify
		}

		self.resp = None
		self.headers = {
			'X-Requested-With': 'ABXaction'
		}
		
		self._login()

	def get(self, path):
		self.resp = self.session.get(url=self._get_url(path), headers=self.headers)
		return self.resp

	def post(self, path, body):
		self.resp = self.session.post(url=self._get_url(path), headers=self.headers, data=body)
		return self.resp

	def is_failed_response(self):
		if self.resp.status_code in [200,201,202]:
			return False
		
		return self._xml2dict(self.resp.content)['SIMPLE_RETURN']['RESPONSE']

	def _get_url(self, path):
		return "{}{}".format(self.base_url, path)
		self.resp = None

	def _login(self):
		LOGIN_API = '/session/'

		body = {
			'action': 'login',
			'username': self.client['username'],
			'password': self.client['password']
		}

		self.session = requests.session()
		self.session.verify = self.client['ssl_verify']

		self.resp = self.post(path=LOGIN_API, body=body)

		if self.is_failed_response():
			raise Exception ('Cannot login to Qualys. Reason: %s' % self.is_failed_response()['TEXT'])

	def _xml2dict(self, txt):
		return xmltodict.parse(txt.decode("utf-8"))

	def __del__(self):
		LOGOUT_API = '/session/'

		body = {
			'action': 'logout'
		}

		self.resp = self.post(path=LOGOUT_API, body=body)

class QualysService:
	def __init__(self, auth) -> None:
		self.client = auth

	def is_failed_response(self):
		return self.client.is_failed_response()

	def scan(self, params):
		path = '/scan/'

		return self.client.post(path, params)

	def report(self, params):
		path = '/report/'

		return self.client.post(path, params)
