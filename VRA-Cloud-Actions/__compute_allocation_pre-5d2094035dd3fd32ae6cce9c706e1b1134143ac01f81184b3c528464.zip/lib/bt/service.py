###
# #%L
# abx.post_provision
# %%
# Copyright (C) 2022 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###

class BTService:
	def __init__(self, auth) -> None:
		self.bt_client = auth

	def is_failed_response(self):
		return self.bt_client.is_failed_response()

	def get_entity_types(self):
		path = '/EntityTypes'

		return self.bt_client.get(path)

	def get_platforms(self):
		path = '/Platforms'

		return self.bt_client.get(path)

	def get_workgroups(self):
		path = '/Workgroups'

		return self.bt_client.get(path)

	def get_workgroups(self):
		path = '/Workgroups'

		return self.bt_client.get(path)

	def get_managed_systems(self):
		path = '/ManagedSystems?limit=1000000'

		return self.bt_client.get(path)

	def get_managed_systems_by_asset(self, asset_id):
		path = '/Assets/%s/ManagedSystems' % (asset_id)

		return self.bt_client.get(path)

	def get_managed_account_by_system(self, system_id):
		path = '/ManagedSystems/%s/ManagedAccounts' % (system_id)

		return self.bt_client.get(path)

	def get_assets_by_workgroup_name(self, workgroup):
		path = '/Workgroups/%s/Assets' % (workgroup)

		return self.bt_client.get(path)

	def add_asset_in_workgroup(self, workgroup, asset_details):
		path = '/Workgroups/%s/Assets' % (workgroup)

		return self.bt_client.post(path, asset_details)

	def add_managed_system_in_workgroup(self, workgroup, ms_details):
		path = '/Workgroups/%s/ManagedSystems' % (workgroup)

		return self.bt_client.post(path, ms_details)

	def add_managed_account_in_managed_system(self, ms_id, ma_details):
		path = '/ManagedSystems/%s/ManagedAccounts' % (ms_id)

		return self.bt_client.post(path, ma_details)

	def remove_asset_in_workgroup(self, workgroup_name, asset_name):
		path = '/Workgroups/%s/Assets?name=%s' % (workgroup_name, asset_name)

		return self.bt_client.delete(path)

	def remove_managed_system(self, system_id):
		path = '/ManagedSystems/%s' % (system_id)

		return self.bt_client.delete(path)

	def remove_all_managed_accounts_by_system(self, system_id):
		path = '/ManagedSystems/%s/ManagedAccounts' % (system_id)

		return self.bt_client.delete(path)
