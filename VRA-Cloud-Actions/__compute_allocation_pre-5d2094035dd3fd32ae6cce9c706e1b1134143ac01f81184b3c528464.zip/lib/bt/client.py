###
# #%L
# abx.post_provision
# %%
# Copyright (C) 2022 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###
import json
import requests

requests.packages.urllib3.disable_warnings(
	requests.packages.urllib3.exceptions.InsecureRequestWarning)

class BTClient:
	def __init__(self, host, port, username, api_key, password=None, challenge = None, ssl_validate=True):
		self.client={
			'host': host,
			'port': port,
			'username': username,
			'key': api_key,
			'password': password,
			'challenge': challenge,
			'connection_certificate_check': ssl_validate
		}
		# DELETE THIS ROW
		self.client['key'] = 'd19c10ed26020ad8f853b89676b8f932fb932001ddcbbdda9f4035911fa36b9dcb1c498c246677660574ca07d32d5665985dff80fb8f5c1e6b966e58c32398c4'

		self.base_url = "https://{}:{}/BeyondTrust/api/public/v3".format(self.client['host'], self.client['port'])
		
		self.resp = None
		self._login()

	def get(self, path):
		self.resp = self.session.get(url=self._get_url(path))
		return self.resp

	def delete(self, path):
		self.resp = self.session.delete(url=self._get_url(path))
		return self.resp

	def post(self, path, body):
		self.resp = self.session.post(url=self._get_url(path), json=body)
		return self.resp

	def put(self, path, body):
		self.resp = self.session.put(url=self._get_url(path), json=body)
		return self.resp

	def patch(self, path, body):
		self.resp = self.session.patch(url=self._get_url(path), json=body)
		return self.resp

	def is_failed_response(self):
		if self.resp.status_code in [200,201,202]:
			return False
		
		return self.resp.reason

	def _get_url(self, path):
		return "{}{}".format(self.base_url, path)

	def _login(self):
		LOGIN_API = '/Auth/SignAppin'
		password_addition=''
		challenge_addition= ''

		if self.client['password'] is not None:
			password_addition = ' pwd=[%s];' % self.client['password']

		if self.client['challenge'] is not None:
			challenge_addition = ' challenge=%s;' % self.client['challenge']

		header = {'Authorization': 'PS-Auth key=%s; runas=%s;%s%s' % (self.client['key'], self.client['username'], password_addition, challenge_addition)}

		self.session = requests.session()
		self.session.verify = self.client['connection_certificate_check']
		self.session.headers.update(header)

		self.resp = self.post(path=LOGIN_API, body='')
		if self.is_failed_response():
			raise Exception ('Cannot login to Beyond Trust Server. Reason: '+ self.is_failed_response())
		
	def __del__(self):
		LOGOUT_API = '/Auth/Signout'

		self.post(path=LOGOUT_API, body='')
