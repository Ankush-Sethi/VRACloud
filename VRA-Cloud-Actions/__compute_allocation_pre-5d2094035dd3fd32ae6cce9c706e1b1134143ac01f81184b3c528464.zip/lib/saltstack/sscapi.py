import sys, os, time

sys.path.append(os.path.join(os.path.dirname(__file__)))

from sseapiclient import APIClient

class SSC(object):
	def __init__(self, raas_url, user, pwd, ssl_validate_cert, auth_token=None):
		self.client = APIClient(
			raas_url,
			user,
			pwd,
			ssl_validate_cert=ssl_validate_cert,
			auth_bearer=auth_token
		)

	def get_vra(self):
		return self.client.api.admin.get_vra_params()

	def discover(self):
		return self.client.api.api.discover()

	def import_scan(self, policy, source, data):
		return self.client.api.vman.import_scan(
			policy_name=policy, 
			thirdparty_source=source, 
			data=data
		)

	def run_assessment_policy(self, policy_id):
		return self.client.api.sec.assess_policy(
			policy_uuid=policy_id
		).ret['jid']

	def get_policy_by_name(self, policy_name):
		return self.client.api.sec.get_policies(
			names=[policy_name]
		).ret['results'][0]['uuid']

	def get_reports(self):
		return self.client.api.vman.get_reports()

	def get_report_by_policy_id(self, policy_id):
		return self.client.api.vman.get_reports(
			policy_uuid=policy_id
		)

	def get_compliant_report(self, policy_id):
		return self.client.api.sec.get_check_minions(
			policy_uuid=policy_id
		).ret['summary']

	def create_target_by_ip(self, name, ip):
		return self.client.api.tgt.save_target_group(
			tgt={
				'*':{
					'tgt_type':'grain',
					'tgt':'ipv4:' + ip
					}
				},
			name = name
		)

	def delete_target(self, target_id):
		return self.client.api.tgt.delete_target_group(
			tgt_uuid= target_id
		)

	def create_policy(self, policy_name, target_id, benchmarks, checks):
		return self.client.api.sec.save_policy(
			name=policy_name,
			tgt_uuid=target_id,
			benchmark_uuids=benchmarks,
			check_uuids=checks
		)

	def delete_policy(self, policy_id):
		return self.client.api.sec.delete_policy(
			policy_uuid=policy_id
		)

	def get_benchmark_ids(self, benchmarks):
		bench_info = self.client.api.sec.get_benchmarks(
			names=benchmarks
		).ret['results']

		return [ bi['uuid'] for bi in bench_info ]

	def get_check_ids_per_benchmarks(self, benchmarks):
		check_info = self.client.api.sec.get_checks(
			benchmark_uuids=benchmarks
		).ret['results']

		return [ ci['uuid'] for ci in check_info ]

	def get_job_result(self, jid):
		return self.client.api.ret.get_returns(
			jid=jid
		).ret

	def wait_for_job(self, jid, wait_period, retries):
		remaining_retries = retries

		jid_result = self.get_job_result(jid)
		while jid_result['count'] == 0 and remaining_retries > 0:
			time.sleep(wait_period);
			jid_result = self.get_job_result(jid)
			remaining_retries = remaining_retries-1

		if jid_result['count'] == 0:
			return {
				"has_errors": True,
				"return": 'No response received from SaltStack for all %s tries made for %s seconds' % (retries+1, (retries*wait_period))
			}
		
		return jid_result['results'][0]
		
	def apply_state(self, minion_id, state_name, pillar_json, environment='sse'):
		return self.client.api.cmd.route_cmd(
			cmd="local",
			fun="state.apply",
			arg={
				'arg': [state_name],
				'kwarg': {
					'pillar': pillar_json,
					'saltenv': environment,
				},
			},
			tgt={
				"*": {
					'tgt': minion_id,
					'tgt_type': 'glob',
				},
			}
		).ret
