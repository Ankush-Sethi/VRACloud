###
# #%L
# abx.post_provision
# %%
# Copyright (C) 2022 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###
import re 

from lib.utils.abx import ABX
from lib.utils.misc import Misc
from lib.utils.log import Logger
from lib.locking.locking import Locking
from lib.custom_hostname.hostname_generator import HostnameGenerator
from lib.vra.providers.AuthClientService import AuthClientService
from lib.vra.providers.AbxService import AbxService
from lib.vra.providers.BlueprintService import BlueprintService
from lib.vra.providers.MachineService import MachineService

PROPERTY_LIST_NAMES={
	'VRA_CRED': '_vRACredentials',
	'VRA_CRED_REFRESH_TOKEN': '_vRARefreshToken',
	'CUST_HOST': '_customHostname',
	'LOG': '_logConfigs'
}

VALIDATION_LIST = [
	[[], [PROPERTY_LIST_NAMES['VRA_CRED'], PROPERTY_LIST_NAMES['VRA_CRED_REFRESH_TOKEN'], PROPERTY_LIST_NAMES['LOG'], PROPERTY_LIST_NAMES['CUST_HOST']]],
	[[PROPERTY_LIST_NAMES['LOG']], ['level'], [[0,1,2,3,4,5]]],
	[[PROPERTY_LIST_NAMES['VRA_CRED']], ['host', 'port', 'connection_certificate_check']],
	[[PROPERTY_LIST_NAMES['CUST_HOST']], ['default_template', 'auto_fill_indexes', 'start_index', 'increment_step', 'max_attempts', 'configuration_name']],
]

LANDING_ZONES = {
	'azure': 'AZ',
	'aws': 'AW',
	'gcp': 'GC',
	'onprem': 'OP'
}

TYPE_OF_DEPLOYMENT = {
	'cio': 'C',
	'non-cio': 'N'
}

AZURE_ENVIRONMENT = {
	'Production': 'P',
	'Development': 'D',
	'PreProduction': 'E', # TODO - change it accordingly
	'QA': 'Q',
	'DR': 'R', # TODO - change it accordingly
	'Test': 'T',
	'POC': 'O' # TODO - change it accordingly
}

def handler(context, inputs):
	# get postprovision metadata. Note we can have multiple machines provisioned
	resource_names = inputs['resourceNames']
	blueprint_request_id = inputs['requestId']
	custom_properties  = inputs['customProperties']

	# utils import
	abx_utils = ABX(context)
	utils = Misc()
	logger = Logger()

	# normalize inputs
	abx_utils.normalize_inputs(inputs)
	
	# validate input parameters
	validation_error = abx_utils.validate_inputs(inputs, VALIDATION_LIST)
	
	if validation_error:
		logger.critical(validation_error)

	# assign inputs to readable variables
	log_configs = inputs[PROPERTY_LIST_NAMES['LOG']]
	vra_credentials = inputs[PROPERTY_LIST_NAMES['VRA_CRED']]
	custom_hostname_configs = inputs[PROPERTY_LIST_NAMES['CUST_HOST']]

	# set new logging level
	logger.set_lvl(log_configs['level'])

	logger.debug('Input data %s' % (inputs))

	# decrypt sensitive inputs
	vra_refresh_token = abx_utils.decrypt_string(inputs[PROPERTY_LIST_NAMES['VRA_CRED_REFRESH_TOKEN']])

	# vRA authentication and vRA services
	vra_client = AuthClientService(host=vra_credentials['host'], port=vra_credentials['port'], refresh_token=vra_refresh_token, ssl_validate=vra_credentials['connection_certificate_check'])
	abx_service = AbxService(vra_client)
	blueprint_service = BlueprintService(vra_client)
	machine_service = MachineService(vra_client)
	
	# get and replace template dynamic values with respective dynamic data
	custom_hostname_template = None
	try:
		custom_hostname_template = custom_properties['customHostname.template']
	except Exception:
		custom_hostname_template = custom_hostname_configs['default_template']

	# get request_details
	blueprint_request_details = blueprint_service.get_blueprint_request_by_id(blueprint_request_id)

	if blueprint_service.is_failed_response():
		raise Exception ('Blueprint details retrieval error: %s' % blueprint_service.is_failed_response()) # type: ignore

	blueprint_request_details = utils.str2json(blueprint_request_details.content)
	
	# placeholder time
	template_placeholders={
		'LandingZone': _get_landing_zone(blueprint_request_details['inputs']),
		'TypeOfDeployment': _get_type_of_deployment(blueprint_request_details['inputs']),
		'ApplicationName': _application_name(blueprint_request_details['inputs']),
		'Environment': _get_environment(blueprint_request_details['inputs']),
		'OS Type': _get_ostype(blueprint_request_details['inputs'])
	}

	try:
		custom_hostname_template = _format_template_literal(custom_hostname_template, template_placeholders)
	except Exception as e:
		logger.error('Cannot find dynamic value for property %s' % (str(e)))
		raise

	# get existing machines (in vRA only)
	vra_machines = machine_service.get_iaas_machines()

	if machine_service.is_failed_response():
		raise Exception ('vRA IAAS machines retrieval error: %s' % machine_service.is_failed_response()) # type: ignore

	vra_machine_names = [p['name'] for p in utils.str2json(vra_machines.content)['content'] if 'name' in p]

	logger.debug('VRA machines %s' % (vra_machine_names))
	
	# vRA Hostname Generator 
	new_hostnames = []
	hostname_validation_services = {
		'vra_machine_service': machine_service
	}

	hostname_generator = HostnameGenerator(
		abx_service, 
		custom_hostname_template, 
		vra_machine_names, 
		custom_hostname_configs, 
		hostname_validation_services
	)

	for _ in resource_names:
		new_hostnames.append(hostname_generator.get_valid_hostname())

	# return new hostnames
	logger.info('Hostnames given: %s' % (new_hostnames))

	return {
		'resourceNames': new_hostnames
	}

def _get_landing_zone(inputs):
	return LANDING_ZONES[
		inputs['landingZone']
	]

def _get_type_of_deployment(inputs):
	return TYPE_OF_DEPLOYMENT[
		inputs['typeOfDeployment']
	]

def _application_name(inputs):
	return inputs['applicationName'][0:6].replace(' ', '-').upper()

def _get_environment(inputs):
	return AZURE_ENVIRONMENT[
		inputs['azureEnvironment']
	]

def _get_ostype(inputs):
	return inputs['osVersion'][0:1].upper()

def _format_template_literal(template, configs):
	# since template is in vRA (Typescript) format, it has to be modified in python native way
	return re.sub(r'\$\{(\#+)\}', r'\1', template) \
				.replace('${','{') \
				.format(**configs)

if __name__ == '__main__':
	handler(
		{},{
		'resourceNames': [ "vra-onprem-23" ],
		"requestId": "e4517249-681a-4e64-87af-baa2b1ae0981",
		"customProperties": "",
		PROPERTY_LIST_NAMES['VRA_CRED']:'{"host":"in.api.mgmt.cloud.vmware.com","port":443,"connection_certificate_check":False}',
		PROPERTY_LIST_NAMES['VRA_CRED_REFRESH_TOKEN']:"",
		PROPERTY_LIST_NAMES['LOG']:'{"level":2}',
		PROPERTY_LIST_NAMES['CUST_HOST']:'{"default_template":"${LandingZone}${TypeOfDeployment}-${ApplicationName}-${Environment}${OS Type}${##}","auto_fill_indexes":False,"start_index":0,"increment_step":1,"max_attempts":3,"configuration_name":"' + PROPERTY_LIST_NAMES['CUST_HOST'] + '"}'
		}
	)
